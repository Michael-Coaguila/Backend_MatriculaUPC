﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBEntity
{
    public class EntitySectionsByCourse
    {
        public int SeccionID { get; set; }
        public string Seccion { get; set; }
        public string Docente { get; set; }
        public string Sede { get; set; }
        public int VacantesOriginales { get; set; }
        public int VacantesRestantes { get; set; }
        public List<EntitySchedulesBySection> Horarios { get; set; }

    }
}
