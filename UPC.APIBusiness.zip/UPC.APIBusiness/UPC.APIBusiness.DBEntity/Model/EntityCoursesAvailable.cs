﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBEntity
{
    public class EntityCoursesAvailable
    {
        public int CursoID { get; set; }
        public string NombreCurso { get; set; }
        public int Creditos { get; set; }
        public int Ciclo { get; set; }
        public List<EntitySectionsByCourse> secciones { get; set; }
    }
}
