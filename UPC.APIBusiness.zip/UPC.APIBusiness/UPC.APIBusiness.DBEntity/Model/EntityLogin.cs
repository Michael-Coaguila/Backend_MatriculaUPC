﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBEntity
{
    public class EntityLogin
    {
        public string Correo { get; set; }
        public string Contrasena { get; set; }
    }
}
