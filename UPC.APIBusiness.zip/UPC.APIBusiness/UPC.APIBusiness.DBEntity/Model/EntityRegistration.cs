﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBEntity
{
    public class EntityRegistration
    {
        public int EstudianteID { get; set; }
        public List<EntityCourseRegistration> CursosMatriculados { get; set; }
    }

    public class EntityCourseRegistration
    {
        public int CursoID { get; set; }
        public int SeccionID { get; set; }
    }
}
