﻿using DBEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBEntity
{
    public class EntityStudentResponse
    {
        public int EstudianteID { get; set; }
        public string Nombre { get; set; }
        public string Codigo { get; set; }
        public string Correo { get; set; }
        public DateTime Turno { get; set; }
        public bool TieneDeuda { get; set; }
        public bool EstaMatriculado { get; set; }
        public string Foto { get; set; }
        public List<EntityCoursesAvailable> CursosDisponibles { get; set; }
        public List<EntityEnrolledCourses> CursosMatriculados { get; set; }
    }
}
