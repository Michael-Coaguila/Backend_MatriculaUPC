﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBEntity
{
    public class EntityEnrolledCourses
    {
        public int CursoId { get; set; }
        public string NombreCurso { get; set; }
        public string Seccion { get; set; }
        public string Docente { get; set; }
        public string Sede { get; set; }
        public EntityScheduleByCourse Horario { get; set; }
    }
}
