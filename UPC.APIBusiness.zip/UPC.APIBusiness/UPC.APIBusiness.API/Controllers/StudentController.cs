﻿using DBContext;
using DBEntity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using NSwag.Annotations;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Threading.Tasks;

namespace API
{
    /// <summary>
    /// 
    /// </summary>
    [Produces("application/json")]
    [Route("api/student")]
    [ApiController]
    public class StudentController : Controller
    {
        /// <summary>
        /// 
        /// </summary>
        protected readonly IStudentRepository _studentRepository;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="studentRepository"></param>
        public StudentController(IStudentRepository studentRepository)
        {
            _studentRepository = studentRepository;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [Produces("application/json")]
        [AllowAnonymous]
        [HttpGet]
        [Route("listar")]
        public ActionResult GetStudents()
        {
            var rest = _studentRepository.GetStudents();
            return Json(rest);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Produces("aplication/json")]
        [AllowAnonymous]
        [HttpGet]
        [Route("obtener")]
        public ActionResult GetStudent(int id)
        {
            var rest = _studentRepository.GetStudent(id);
            if ( rest.IsSuccess)
            {
                var responseStudent = rest.Data as EntityStudentResponse;
                rest.Data = responseStudent;
            }
            return Json(rest);
        }
    }
}
