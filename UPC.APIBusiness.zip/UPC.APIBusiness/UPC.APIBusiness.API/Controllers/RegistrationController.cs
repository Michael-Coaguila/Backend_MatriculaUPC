﻿using DBContext;
using DBEntity;
using Microsoft.AspNetCore.Mvc;

namespace UPC.APIBusiness.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    
    public class RegistrationController : Controller
    {
        private readonly IRegistrationRepository _matriculaRepository;

        public RegistrationController(IRegistrationRepository matriculaRepository)
        {
            _matriculaRepository = matriculaRepository;
        }

        [HttpPost("register")]
        public IActionResult RegistrarMatricula([FromBody] EntityRegistration matricula)
        {
            if (matricula == null || matricula.CursosMatriculados == null || matricula.CursosMatriculados.Count == 0)
            {
                return BadRequest("Datos de matrícula no válidos.");
            }

            var response = _matriculaRepository.RegistrarMatricula(matricula);

            if (response.IsSuccess)
            {
                return Ok(response);
            }

            return BadRequest(response);
        }
    }
}
