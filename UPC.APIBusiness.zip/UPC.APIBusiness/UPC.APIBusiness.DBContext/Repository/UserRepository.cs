﻿using Dapper;
using DBEntity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace DBContext
{
    public class UserRepository : BaseRepository, IUserRepository
    {
        public EntityBaseResponse Login(EntityLogin login)
        {
            var response = new EntityBaseResponse();
            try
            {
                using (var db = GetSqlConnection())
                {
                    var user = new EntityLoginResponse();

                    const string sql = "sp_AuthUsuario";
                    var p = new DynamicParameters();

                    p.Add(name: "@Correo", value: login.Correo, dbType: DbType.String, direction: ParameterDirection.Input);
                    p.Add(name: "@Contrasena", value: login.Contrasena, dbType: DbType.String, direction: ParameterDirection.Input);

                    user = db.Query<EntityLoginResponse>(
                        sql: sql,
                        param: p,
                        commandType: CommandType.StoredProcedure
                        ).FirstOrDefault();

                    if ( user != null ) 
                    {
                        response.IsSuccess = true;
                        response.ErrorCode = "0000";
                        response.ErrorMessage = string.Empty;
                        response.Data = user;
                    } else {
                        response.IsSuccess = false;
                        response.ErrorCode = "0000";
                        response.ErrorMessage = string.Empty;
                        response.Data = null;
                    }
                }
            } catch (Exception ex)
            {
                // Registrar el mensaje de la excepción y la pila de excepciones para más detalles
                Console.WriteLine($"Error en el método Login: {ex.Message}");
                Console.WriteLine($"StackTrace: {ex.StackTrace}");

                response.IsSuccess = false;
                response.ErrorCode = "0001";
                response.ErrorMessage = $"Error en el servidor: {ex.Message}"; // Incluye detalles del error
                response.Data = null;
            }
            return response;
        }
    }
}
