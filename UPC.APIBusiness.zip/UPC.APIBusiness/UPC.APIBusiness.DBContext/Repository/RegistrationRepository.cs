﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DBEntity;
using Dapper;

namespace DBContext
{
    public class RegistrationRepository : BaseRepository, IRegistrationRepository
    {
        public EntityBaseResponse RegistrarMatricula(EntityRegistration matricula)
        {
            var response = new EntityBaseResponse();
            try
            {
                using (var db = GetSqlConnection())
                {
                    using (var transaction = db.BeginTransaction())
                    {
                        const string sqlMatricula = "sp_RegistrarMatricula";

                        foreach (var curso in matricula.CursosMatriculados)
                        {
                            var parameters = new DynamicParameters();
                            parameters.Add("@EstudianteID", matricula.EstudianteID);
                            parameters.Add("@SeccionID", curso.SeccionID);

                            db.Execute(sqlMatricula, parameters, transaction: transaction, commandType: CommandType.StoredProcedure);
                        }

                        transaction.Commit();
                        response.IsSuccess = true;
                        response.ErrorCode = "0000";
                        response.ErrorMessage = "Matrícula registrada exitosamente.";
                    }
                }
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.ErrorCode = "0001";
                response.ErrorMessage = ex.Message;
            }

            return response;
        }
    }
}


