﻿using Dapper;
using DBEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using static System.Net.Mime.MediaTypeNames;

namespace DBContext
{
    public class CoursesAvailableRepository : BaseRepository, ICoursesAvailableRepository
    {
        public EntityBaseResponse GetCoursesAvailable(int id)
        {
            var response = new EntityBaseResponse();
            try
            {
                using (var db = GetSqlConnection())
                {
                    var sections = new List<EntityCoursesAvailable>();
                    const string sql = "sp_GetCursosDisponiblesPorEstudiante";

                    var p = new DynamicParameters();
                    p.Add(name: "@EstudianteID", value: id, dbType: System.Data.DbType.Int32, direction: System.Data.ParameterDirection.Input);

                    sections = db.Query<EntityCoursesAvailable> (
                        sql: sql,
                        param: p,
                        commandType: CommandType.StoredProcedure
                       ).ToList();

                    if ( sections.Count > 0 )
                    {
                        var repoSectionsByCourse = new SectionsByCourseRepository();
                        foreach (var sec in sections)
                        {
                            sec.secciones = repoSectionsByCourse.GetSectionsByCourse(sec.CursoID).Data as List<EntitySectionsByCourse>;
                        }
                        response.IsSuccess = true;
                        response.ErrorCode = "0000";
                        response.ErrorMessage = string.Empty;
                        response.Data = sections;
                    }
                    else
                    {
                        response.IsSuccess = false;
                        response.ErrorCode = "0001";
                        response.ErrorMessage = string.Empty;
                        response.Data = null;
                    }
                }
            } catch (Exception ex)
            {
                response.IsSuccess = false;
                response.ErrorCode = "0001";
                response.ErrorMessage = ex.Message;
                response.Data = null;
            }
            return response;
        }
    }
}
