﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DBEntity;
using Dapper;

namespace DBContext
{
    public class EnrolledCoursesRepository : BaseRepository, IEnrolledCoursesRepository
    {
        public EntityBaseResponse GetEnrolledCourses(int id)
        {
            var response = new EntityBaseResponse();
            try
            {
                using (var db = GetSqlConnection())
                {
                    var enrollments = new List<EntityEnrolledCourses>();
                    const string sql = "sp_GetCursosMatriculadosPorEstudiante";

                    var p = new DynamicParameters();
                    p.Add(name: "@EstudianteID", value: id, dbType: DbType.Int32, direction: ParameterDirection.Input);

                    enrollments = db.Query<EntityEnrolledCourses>(
                        sql: sql,
                        param: p,
                        commandType: CommandType.StoredProcedure
                       ).ToList();

                    if (enrollments.Count > 0)
                    {
                        var repoScheduleByCourse = new ScheduleByCourseRepository();
                        foreach (var cor in enrollments)
                        {
                            cor.Horario = repoScheduleByCourse.GetScheduleByCourse(cor.CursoId).Data as EntityScheduleByCourse;
                        }

                        response.IsSuccess = true;
                        response.ErrorCode = "0000";
                        response.ErrorMessage = string.Empty;
                        response.Data = enrollments;
                    }
                    else
                    {
                        response.IsSuccess = false;
                        response.ErrorCode = "0001";
                        response.ErrorMessage = string.Empty;
                        response.Data = null;
                    }
                }
            } catch (Exception ex)
            {
                response.IsSuccess = false;
                response.ErrorCode = "0001";
                response.ErrorMessage = ex.Message;
                response.Data = null;
            }
            return response;
        }
    }
}
