﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DBEntity;
using System.Data.SqlClient;
using Dapper;

namespace DBContext
{
    public class SectionsByCourseRepository : BaseRepository, ISectionsByCourseRepository
    {
        public EntityBaseResponse GetSectionsByCourse(int id)
        {
            var response = new EntityBaseResponse();
            try
            {
                using (var db = GetSqlConnection())
                {
                    var secciones = new List<EntitySectionsByCourse>();
                    const string sql = "sp_GetSeccionesPorCurso";

                    var p = new DynamicParameters();
                    p.Add(name: "@CursoID", value: id, dbType: DbType.Int32, direction: ParameterDirection.Input);

                    secciones = db.Query<EntitySectionsByCourse>(
                        sql: sql,
                        param: p,
                        commandType: CommandType.StoredProcedure
                       ).ToList();

                    if (secciones.Count > 0)
                    {
                        var repoSchedulesBySection = new SchedulesBySectionRepository();
                        foreach (var sec in secciones)
                        {
                            sec.Horarios = repoSchedulesBySection.GetSchedulesBySection(sec.SeccionID).Data as List<EntitySchedulesBySection>;
                        }
                        response.IsSuccess = true;
                        response.ErrorCode = "0000";
                        response.ErrorMessage = string.Empty;
                        response.Data = secciones;
                    }
                    else
                    {
                        response.IsSuccess = false;
                        response.ErrorCode = "0001";
                        response.ErrorMessage = string.Empty;
                        response.Data = null;
                    }
                }
            } catch (Exception ex)
            {
                response.IsSuccess = false;
                response.ErrorCode = "0001";
                response.ErrorMessage = ex.Message;
                response.Data = null;
            }
            return response;
        }
    }
}
