﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DBEntity;
using Dapper;

namespace DBContext
{
    public class SchedulesBySectionRepository : BaseRepository, ISchedulesBySectionRepository
    {
        public EntityBaseResponse GetSchedulesBySection(int id)
        {
            var response = new EntityBaseResponse();
            try
            {
                using (var db = GetSqlConnection())
                {
                    var schedules = new List<EntitySchedulesBySection>();

                    const string sql = "sp_GetHorarioPorSeccion";
                    
                    var p = new DynamicParameters();
                    p.Add(name: "@SeccionID", value: id, dbType: DbType.Int32, direction: ParameterDirection.Input);

                    schedules = db.Query<EntitySchedulesBySection>(
                        sql: sql,
                        param: p,
                        commandType: CommandType.StoredProcedure
                        ).ToList();

                    if ( schedules.Count > 0 ) {
                        response.IsSuccess = true;
                        response.ErrorCode = "0000";
                        response.ErrorMessage = string.Empty;
                        response.Data = schedules;
                    }
                    else
                    {
                        response.IsSuccess = false;
                        response.ErrorCode = "0001";
                        response.ErrorMessage = string.Empty;
                        response.Data = null;


                    }
                }
            } catch (Exception ex)
            {
                response.IsSuccess = false;
                response.ErrorCode = "0001";
                response.ErrorMessage = ex.Message;
                response.Data = null;
            }
            return response;
        }
    }

}
