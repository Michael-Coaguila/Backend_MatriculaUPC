﻿using DBEntity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace DBContext
{
    public class StudentRepository : BaseRepository, IStudentRepository
    {
        public EntityBaseResponse GetStudent(int studentId)
        {

            var response = new EntityBaseResponse();
            try
            {
                using (var db = GetSqlConnection())
                {
                    var student = new EntityStudentResponse();

                    const string sql = "sp_GetDatosEstudiantePorID";
                    var p = new DynamicParameters();
                    p.Add(name: "@EstudianteID", value: studentId, dbType: DbType.Int32, direction: ParameterDirection.Input);

                    student = db.Query<EntityStudentResponse>(

                        sql: sql,
                        param: p,
                        commandType: CommandType.StoredProcedure
                        ).FirstOrDefault();

                    if (student != null)
                    {
                        var repoCoursesAvailable = new CoursesAvailableRepository();
                        student.CursosDisponibles = repoCoursesAvailable.GetCoursesAvailable(student.EstudianteID).Data as List<EntityCoursesAvailable>;
                        if (student.EstaMatriculado)
                        {
                            var repoEnrolledCourses = new EnrolledCoursesRepository();
                            student.CursosMatriculados = repoEnrolledCourses.GetEnrolledCourses(student.EstudianteID).Data as List<EntityEnrolledCourses>;
                        }

                        response.IsSuccess = true;
                        response.ErrorCode = "0000";
                        response.ErrorMessage = string.Empty;
                        response.Data = student;
                    }
                    else
                    {
                        response.IsSuccess = false;
                        response.ErrorCode = "0000";
                        response.ErrorMessage = string.Empty;
                        response.Data = null;
                    }
                }
            } catch (Exception ex)
            {
                response.IsSuccess = false;
                response.ErrorCode = "0000";
                response.ErrorMessage = ex.Message;
                response.Data = null;
            }
            return response;
        }

        public EntityBaseResponse GetStudents()
        {
            var response = new EntityBaseResponse();
            try
            {
                using (var db = GetSqlConnection())
                {
                    var students = new List<EntityStudent>();
                    const string sql = "SELECT * FROM Estudiantes"; //sp_GetTodosEstudiantes
                    students = db.Query<EntityStudent>(
                        sql: sql,
                        commandType: CommandType.Text //StoredProcedure
                        ).ToList();

                    if (students.Count > 0)
                    {
                        var repoCoursesAvailable = new CoursesAvailableRepository();
                        foreach (var std in students)
                        {
                            std.CursosDisponibles = repoCoursesAvailable.GetCoursesAvailable(std.EstudianteID).Data as List<EntityCoursesAvailable>;
                        }

                        var repoEnrolledCourses = new EnrolledCoursesRepository();
                        foreach (var std in students)
                        {
                            if (std.EstaMatriculado)
                                std.CursosMatriculados = repoEnrolledCourses.GetEnrolledCourses(std.EstudianteID).Data as List<EntityEnrolledCourses>;
                        }

                        response.IsSuccess = true;
                        response.ErrorCode = "0000";
                        response.ErrorMessage = string.Empty;
                        response.Data = students;
                    }
                    else
                    {
                        response.IsSuccess = false;
                        response.ErrorCode = "0000";
                        response.ErrorMessage = string.Empty;
                        response.Data = null;
                    }
                }
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.ErrorCode = "0001";
                response.ErrorMessage = ex.Message;
                response.Data = null;
            }
            return response;
        }
    }
}
